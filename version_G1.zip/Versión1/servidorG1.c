#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <my_global.h>
#include <mysql.h>


int main(int argc, char *argv[]) 
{
	
	MYSQL *conn;
	int err;
	MYSQL_RES *resultado;
	MYSQL_ROW row;
	conn = mysql_init(NULL);
	
	if (conn==NULL) {
		printf ("Error al crear la on: %u %s\n",
				mysql_errno(conn), mysql_error(conn));
		exit (1);
	}

	conn = mysql_real_connect (conn, "localhost","root", "mysql", "Campeonato",0, NULL, 0);
	
	if (conn==NULL) {
		printf ("Error al inicializar la conexion: %u %s\n",
				mysql_errno(conn), mysql_error(conn))
		exit (1);
	}
	
	
	int sock_conn, sock_listen, ret;
	struct sockaddr_in serv_adr;
	char peticion[512];
	char respuesta[512];
	
	if ((sock_listen = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		printf("Error creant socket");
	
	memset(&serv_adr, 0, sizeof(serv_adr));
	serv_adr.sin_family = AF_INET;
	
	serv_adr.sin_addr.s_addr = htonl(INADDR_ANY);
	
	serv_adr.sin_port = htons(9050);
	if (bind(sock_listen, (struct sockaddr *) &serv_adr, sizeof(serv_adr)) < 0)
		printf ("Error al bind");
	
	if (listen(sock_listen, 3) < 0)
		printf ("Error en la escucha");
	
	int i;
	for (i=0;i<100;i++){
		printf ("Escuchando\n");
		
		sock_conn = accept(sock_listen, NULL, NULL);
		printf("Conexi�n recibida\n");
		
		ret=read(sock_conn,peticion, sizeof(peticion));
		printf("Recibido\n");
		
		peticion[ret]='\0';
		
		printf("Peticion: %s\n",peticion);
		
		char *p = strtok(peticion, "/");
		int codigo = atoi(p);
		p = strtok(NULL, "/");
		char nombre[20];
		int gradosc = atof (p);
		
		if (codigo == 1){
			resultado = mysql_store_result (conn);
			row = mysql_fetch_row (resultado);
			int contador = 0;
			if (row == NULL)
				printf ("No se han obtenido datos en la consulta\n");
			else
				while (row !=NULL) {
					contador++;
					return contador;
					
				}
				printf("%s ha jugado %u partidas\n", nom, contador);
				mysql_close (conn);
				exit(0);
				char consulta [80];
				
				strcpy (consulta,"SELECT Jugadores.Nombre FROM Jugadores, Ranking WHERE Jugadores.Nombre = " nom);
				strcat (consulta, nom)  
					err=mysql_query (conn, consulta);
				
				if (err!=0) {
					printf ("Error al consultar datos de la base %u %s\n",
							mysql_errno(conn), mysql_error(conn));
					exit (1);
				}
		}
			
		else if (codigo == 2){
			resultado = mysql_store_result (conn);
			row = mysql_fetch_row (resultado);
			int contador = 0;
			if (row == NULL)
				printf ("No se han obtenido datos en la consulta\n");
			else
				char consulta [80];
				
				strcpy (consulta,"SELECT Jugadores.Nombre FROM Jugadores, Ranking, Partidas WHERE Partidas.Fecha =" data);
				strcat (consulta, nom)  
					err=mysql_query (conn, consulta);
				printf(jugadores.Nombre);
				if (err!=0) {
					printf ("Error al consultar datos de la base %u %s\n",
							mysql_errno(conn), mysql_error(conn));
					exit (1);
				}
		}
			
			
		else if (codigo == 3){
			resultado = mysql_store_result (conn);
			row = mysql_fetch_row (resultado);
			int contador = 0;
			if (row == NULL)
				printf ("No se han obtenido datos en la consulta\n");
			else
				char consulta [80];
			
			strcpy (consulta,"SELECT Ranking.ID_r FROM Jugadores, Ranking, Partidas WHERE Jugadores.Nombre = " nombre);
			strcat (consulta, nom)  
				err=mysql_query (conn, consulta);
			printf(Ranking.ID_r);
			if (err!=0) {
				printf ("Error al consultar datos de la base %u %s\n",
						mysql_errno(conn), mysql_error(conn));
				exit (1);
			}
		}
			
	}
	
	close (sock_conn);
		
}

