﻿namespace WindowsFormsApplication1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.JugadoresPartida = new System.Windows.Forms.RadioButton();
            this.Posicion = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.partidaBox = new System.Windows.Forms.TextBox();
            this.NumeroPartidas = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.nombre = new System.Windows.Forms.TextBox();
            this.Conectar = new System.Windows.Forms.Button();
            this.Desconectar = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.groupBox1.Controls.Add(this.JugadoresPartida);
            this.groupBox1.Controls.Add(this.Posicion);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.partidaBox);
            this.groupBox1.Controls.Add(this.NumeroPartidas);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.nombre);
            this.groupBox1.Location = new System.Drawing.Point(306, 220);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Size = new System.Drawing.Size(544, 311);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Peticion";
            // 
            // JugadoresPartida
            // 
            this.JugadoresPartida.AutoSize = true;
            this.JugadoresPartida.Location = new System.Drawing.Point(174, 140);
            this.JugadoresPartida.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.JugadoresPartida.Name = "JugadoresPartida";
            this.JugadoresPartida.Size = new System.Drawing.Size(288, 24);
            this.JugadoresPartida.TabIndex = 7;
            this.JugadoresPartida.TabStop = true;
            this.JugadoresPartida.Text = "Cuantos jugadores hay en la partida";
            this.JugadoresPartida.UseVisualStyleBackColor = true;
            // 
            // Posicion
            // 
            this.Posicion.AutoSize = true;
            this.Posicion.Location = new System.Drawing.Point(174, 182);
            this.Posicion.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Posicion.Name = "Posicion";
            this.Posicion.Size = new System.Drawing.Size(249, 24);
            this.Posicion.TabIndex = 7;
            this.Posicion.TabStop = true;
            this.Posicion.Text = "Que posicion del ranking estoy";
            this.Posicion.UseVisualStyleBackColor = true;
            this.Posicion.CheckedChanged += new System.EventHandler(this.altura_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(28, 140);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "Partida";
            // 
            // partidaBox
            // 
            this.partidaBox.Location = new System.Drawing.Point(22, 169);
            this.partidaBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.partidaBox.Name = "partidaBox";
            this.partidaBox.Size = new System.Drawing.Size(91, 26);
            this.partidaBox.TabIndex = 9;
            // 
            // NumeroPartidas
            // 
            this.NumeroPartidas.AutoSize = true;
            this.NumeroPartidas.Location = new System.Drawing.Point(174, 105);
            this.NumeroPartidas.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.NumeroPartidas.Name = "NumeroPartidas";
            this.NumeroPartidas.Size = new System.Drawing.Size(229, 24);
            this.NumeroPartidas.TabIndex = 8;
            this.NumeroPartidas.TabStop = true;
            this.NumeroPartidas.Text = "Cuantas partidas he jugado";
            this.NumeroPartidas.UseVisualStyleBackColor = true;
            this.NumeroPartidas.CheckedChanged += new System.EventHandler(this.Bonito_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(35, 39);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(132, 37);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nombre";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(189, 241);
            this.button2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(112, 35);
            this.button2.TabIndex = 5;
            this.button2.Text = "Enviar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // nombre
            // 
            this.nombre.Location = new System.Drawing.Point(174, 48);
            this.nombre.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.nombre.Name = "nombre";
            this.nombre.Size = new System.Drawing.Size(244, 26);
            this.nombre.TabIndex = 3;
            // 
            // Conectar
            // 
            this.Conectar.Location = new System.Drawing.Point(140, 72);
            this.Conectar.Name = "Conectar";
            this.Conectar.Size = new System.Drawing.Size(181, 67);
            this.Conectar.TabIndex = 8;
            this.Conectar.Text = "Conectar";
            this.Conectar.UseVisualStyleBackColor = true;
            this.Conectar.Click += new System.EventHandler(this.Conectar_Click);
            // 
            // Desconectar
            // 
            this.Desconectar.Location = new System.Drawing.Point(140, 593);
            this.Desconectar.Name = "Desconectar";
            this.Desconectar.Size = new System.Drawing.Size(181, 67);
            this.Desconectar.TabIndex = 9;
            this.Desconectar.Text = "Desconectar";
            this.Desconectar.UseVisualStyleBackColor = true;
            this.Desconectar.Click += new System.EventHandler(this.Desconectar_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1155, 751);
            this.Controls.Add(this.Desconectar);
            this.Controls.Add(this.Conectar);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton JugadoresPartida;
        private System.Windows.Forms.RadioButton Posicion;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox partidaBox;
        private System.Windows.Forms.RadioButton NumeroPartidas;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox nombre;
        private System.Windows.Forms.Button Conectar;
        private System.Windows.Forms.Button Desconectar;
    }
}